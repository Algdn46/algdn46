#include <stdio.h>
#include <ta-lib/ta_libc.h>
int main() {
    TA_RetCode ret = TA_Initialize();
    if (ret == TA_SUCCESS) {
        printf("TA-Lib başarıyla başlatıldı!\n");
        TA_Shutdown();
    } else {
        printf("TA-Lib başlatılamadı, hata kodu: %d\n", ret);
    }
    return 0;
}




